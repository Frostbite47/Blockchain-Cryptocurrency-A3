// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/AccessControl.sol";

contract UmerKhalid_SupplyChain is AccessControl {

    // -------------------------------------------------
    // Roles
    // -------------------------------------------------
    bytes32 public constant MANUFACTURER_ROLE = keccak256("MANUFACTURER_ROLE");
    bytes32 public constant DISTRIBUTOR_ROLE  = keccak256("DISTRIBUTOR_ROLE");
    bytes32 public constant RETAILER_ROLE     = keccak256("RETAILER_ROLE");
    bytes32 public constant CUSTOMER_ROLE     = keccak256("CUSTOMER_ROLE");

    // -------------------------------------------------
    // Status
    // -------------------------------------------------
    enum Status {
        Manufactured,
        InTransitToDistributor,
        AtDistributor,
        InTransitToRetailer,
        AtRetailer,
        SoldToCustomer
    }

    // -------------------------------------------------
    // Structs
    // -------------------------------------------------
    struct Product {
        uint256 id;
        string  name;
        string  description;
        address currentOwner;
        Status  status;
        bool    exists;
    }

    struct HistoryEntry {
        address owner;
        Status  status;
        uint256 timestamp;
    }

    // -------------------------------------------------
    // Storage
    // -------------------------------------------------
    uint256 private _productCounter;

    mapping(uint256 => Product)        public  products;
    mapping(uint256 => HistoryEntry[]) private productHistory;

    // -------------------------------------------------
    // Events
    // -------------------------------------------------
    event ProductRegistered(uint256 indexed productId, address manufacturer, uint256 timestamp);
    event ProductTransferred(uint256 indexed productId, address from, address to, Status status, uint256 timestamp);
    event DeliveryConfirmed(uint256 indexed productId, address by, Status status, uint256 timestamp);

    // -------------------------------------------------
    // Constructor
    // -------------------------------------------------
    constructor() {
        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _grantRole(MANUFACTURER_ROLE, msg.sender);
    }

    // -------------------------------------------------
    // Register Product (Manufacturer only)
    // Auto-increments ID — no manual ID needed
    // -------------------------------------------------
    function registerProduct(
        string memory _name,
        string memory _description
    ) public onlyRole(MANUFACTURER_ROLE) returns (uint256) {

        _productCounter++;
        uint256 newId = _productCounter;

        products[newId] = Product({
            id:           newId,
            name:         _name,
            description:  _description,
            currentOwner: msg.sender,
            status:       Status.Manufactured,
            exists:       true
        });

        productHistory[newId].push(HistoryEntry({
            owner:     msg.sender,
            status:    Status.Manufactured,
            timestamp: block.timestamp
        }));

        emit ProductRegistered(newId, msg.sender, block.timestamp);
        return newId;
    }

    // -------------------------------------------------
    // Transfer Product (strict role flow)
    // -------------------------------------------------
    function transferProduct(uint256 _id, address _newOwner) public {

        require(products[_id].exists,                          "Product does not exist");
        require(products[_id].currentOwner == msg.sender,      "Not current owner");

        Product storage product = products[_id];
        Status newStatus;

        if (hasRole(MANUFACTURER_ROLE, msg.sender)) {
            require(hasRole(DISTRIBUTOR_ROLE, _newOwner),  "Must transfer to Distributor");
            newStatus = Status.InTransitToDistributor;

        } else if (hasRole(DISTRIBUTOR_ROLE, msg.sender)) {
            require(product.status == Status.AtDistributor, "Must confirm receipt before transferring");
            require(hasRole(RETAILER_ROLE, _newOwner),      "Must transfer to Retailer");
            newStatus = Status.InTransitToRetailer;

        } else if (hasRole(RETAILER_ROLE, msg.sender)) {
            require(product.status == Status.AtRetailer,    "Must confirm receipt before transferring");
            require(hasRole(CUSTOMER_ROLE, _newOwner),      "Must transfer to Customer");
            newStatus = Status.SoldToCustomer;

        } else {
            revert("Invalid role for transfer");
        }

        product.status       = newStatus;
        product.currentOwner = _newOwner;

        productHistory[_id].push(HistoryEntry({
            owner:     _newOwner,
            status:    newStatus,
            timestamp: block.timestamp
        }));

        emit ProductTransferred(_id, msg.sender, _newOwner, newStatus, block.timestamp);
    }

    // -------------------------------------------------
    // Confirm Delivery (Distributor or Retailer)
    // Must be called by the new owner after receiving
    // -------------------------------------------------
    function confirmDelivery(uint256 _id) public {

        require(products[_id].exists,                     "Product does not exist");
        require(products[_id].currentOwner == msg.sender, "Not current owner");

        Product storage product = products[_id];
        Status newStatus;

        if (hasRole(DISTRIBUTOR_ROLE, msg.sender) &&
            product.status == Status.InTransitToDistributor) {
            newStatus = Status.AtDistributor;

        } else if (hasRole(RETAILER_ROLE, msg.sender) &&
                   product.status == Status.InTransitToRetailer) {
            newStatus = Status.AtRetailer;

        } else {
            revert("Cannot confirm delivery at this stage");
        }

        product.status = newStatus;

        productHistory[_id].push(HistoryEntry({
            owner:     msg.sender,
            status:    newStatus,
            timestamp: block.timestamp
        }));

        emit DeliveryConfirmed(_id, msg.sender, newStatus, block.timestamp);
    }

    // -------------------------------------------------
    // View Product
    // -------------------------------------------------
    function getProduct(uint256 _id)
        public
        view
        returns (
            uint256,
            string memory,
            string memory,
            address,
            Status
        )
    {
        require(products[_id].exists, "Product does not exist");
        Product memory p = products[_id];
        return (p.id, p.name, p.description, p.currentOwner, p.status);
    }

    // -------------------------------------------------
    // View Full Audit Trail (with timestamps)
    // -------------------------------------------------
    function getProductHistory(uint256 _id)
        public
        view
        returns (HistoryEntry[] memory)
    {
        require(products[_id].exists, "Product does not exist");
        return productHistory[_id];
    }

    // -------------------------------------------------
    // View total products registered
    // -------------------------------------------------
    function getTotalProducts() public view returns (uint256) {
        return _productCounter;
    }

    // -------------------------------------------------
    // Admin: Add roles
    // -------------------------------------------------
    function addManufacturer(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        grantRole(MANUFACTURER_ROLE, account);
    }

    function addDistributor(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        grantRole(DISTRIBUTOR_ROLE, account);
    }

    function addRetailer(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        grantRole(RETAILER_ROLE, account);
    }

    function addCustomer(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        grantRole(CUSTOMER_ROLE, account);
    }

    // -------------------------------------------------
    // Admin: Revoke roles
    // -------------------------------------------------
    function removeManufacturer(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        revokeRole(MANUFACTURER_ROLE, account);
    }

    function removeDistributor(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        revokeRole(DISTRIBUTOR_ROLE, account);
    }

    function removeRetailer(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        revokeRole(RETAILER_ROLE, account);
    }

    function removeCustomer(address account) public onlyRole(DEFAULT_ADMIN_ROLE) {
        revokeRole(CUSTOMER_ROLE, account);
    }
}