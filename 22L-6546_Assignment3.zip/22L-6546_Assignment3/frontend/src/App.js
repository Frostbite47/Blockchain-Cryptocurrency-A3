﻿import { useState } from "react";
import { ethers } from "ethers";
import contractData from "./abis/UmerKhalid_SupplyChain.json";

const CONTRACT_ADDRESS = "0x951897b876E309F031f0DB6A7BfB4Af63544c445";
const ABI = contractData.abi;

const statusMap = [
    "Manufactured",
    "In Transit to Distributor",
    "At Distributor",
    "In Transit to Retailer",
    "At Retailer",
    "Sold to Customer"
];

function App() {
    const [contract, setContract]         = useState(null);
    const [walletAddress, setWalletAddress] = useState("");
    const [error, setError]               = useState("");
    const [success, setSuccess]           = useState("");

    // Register
    const [regName, setRegName]   = useState("");
    const [regDesc, setRegDesc]   = useState("");

    // Product lookup / transfer / confirm
    const [productId, setProductId] = useState("");
    const [newOwner, setNewOwner]   = useState("");
    const [productInfo, setProductInfo] = useState(null);
    const [history, setHistory]     = useState([]);

    function notify(msg) {
        setSuccess(msg);
        setError("");
    }

    function fail(msg) {
        setError(msg);
        setSuccess("");
    }

    // ── Connect Wallet ──────────────────────────────────────
    async function connectWallet() {
        try {
            if (!window.ethereum) throw new Error("MetaMask not installed");

            const provider = new ethers.BrowserProvider(window.ethereum);
            await provider.send("eth_requestAccounts", []);
            const signer = await provider.getSigner();
            const addr   = await signer.getAddress();

            const instance = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);
            setContract(instance);
            setWalletAddress(addr);
            notify("Wallet connected successfully");
        } catch (err) {
            fail(err.message);
        }
    }

    // ── Register Product ────────────────────────────────────
    async function registerProduct() {
        try {
            if (!contract)       return fail("Connect wallet first");
            if (!regName.trim()) return fail("Product name is required");
            if (!regDesc.trim()) return fail("Description is required");

            // New contract takes only (name, description) — no manual ID
            const tx = await contract.registerProduct(regName.trim(), regDesc.trim(), {
                gasLimit: 300000,
                gasPrice: ethers.parseUnits("35", "gwei")
            });
            const receipt = await tx.wait();

            // Read the assigned ID from the ProductRegistered event
            const event  = receipt.logs
                .map(log => { try { return contract.interface.parseLog(log); } catch { return null; } })
                .find(e => e && e.name === "ProductRegistered");

            const assignedId = event ? event.args.productId.toString() : "?";

            notify(`Product registered! Assigned ID: ${assignedId}`);
            setProductId(assignedId);
            setRegName("");
            setRegDesc("");

            // Auto-load the new product
            await fetchProduct(assignedId);
        } catch (err) {
            fail("Registration failed — are you a Manufacturer?");
            console.error(err);
        }
    }

    // ── Get Product ─────────────────────────────────────────
    async function fetchProduct(id) {
        const idNum = Number(id ?? productId);
        try {
            if (!contract)   return fail("Connect wallet first");
            if (!idNum)      return fail("Enter a valid product ID");

            const data = await contract.getProduct(idNum);
            setProductInfo({
                id:     data[0].toString(),
                name:   data[1],
                desc:   data[2],
                owner:  data[3],
                status: statusMap[Number(data[4])]
            });
            setError("");
        } catch (err) {
            fail("Product not found");
            console.error(err);
        }
    }

    // ── Transfer Product ────────────────────────────────────
    async function transferProduct() {
        try {
            if (!contract)         return fail("Connect wallet first");
            if (!productId)        return fail("Enter a product ID");
            if (!newOwner.trim())  return fail("Enter the new owner address");

            const tx = await contract.transferProduct(Number(productId), newOwner.trim(), {
                gasLimit: 300000,
                gasPrice: ethers.parseUnits("35", "gwei")
            });
            await tx.wait();

            notify("Product transferred successfully");
            setNewOwner("");
            await fetchProduct(productId);
            await loadHistory();
        } catch (err) {
            fail("Transfer failed — check ownership and roles");
            console.error(err);
        }
    }

    // ── Confirm Delivery ────────────────────────────────────
    async function confirmDelivery() {
        try {
            if (!contract)  return fail("Connect wallet first");
            if (!productId) return fail("Enter a product ID");

            const tx = await contract.confirmDelivery(Number(productId), {
                gasLimit: 300000,
                gasPrice: ethers.parseUnits("35", "gwei")
            });
            await tx.wait();

            notify("Delivery confirmed successfully");
            await fetchProduct(productId);
            await loadHistory();
        } catch (err) {
            fail("Confirm failed — only Distributor/Retailer after receiving");
            console.error(err);
        }
    }

    // ── Audit Trail ─────────────────────────────────────────
    async function loadHistory() {
        try {
            if (!contract)  return fail("Connect wallet first");
            if (!productId) return fail("Enter a product ID");

            // Use the view function — returns HistoryEntry[] with timestamps
            const entries = await contract.getProductHistory(Number(productId));
            setHistory(entries.map(e => ({
                owner:     e.owner,
                status:    statusMap[Number(e.status)],
                timestamp: new Date(Number(e.timestamp) * 1000).toLocaleString()
            })));
            setError("");
        } catch (err) {
            fail("Could not fetch history");
            console.error(err);
        }
    }

    async function checkRoles() {
        try {
            const MANU_ROLE = await contract.MANUFACTURER_ROLE();
            const DIST_ROLE = await contract.DISTRIBUTOR_ROLE();
            const RET_ROLE = await contract.RETAILER_ROLE();
            const CUST_ROLE = await contract.CUSTOMER_ROLE();

            const manu = await contract.hasRole(MANU_ROLE, "0x93BA8Ee096C7B80F358AEAEd24a49Fc7b3B0E65E");
            const dist = await contract.hasRole(DIST_ROLE, "0x59e2AeC261C8B3238a051ff9c9086C3d9079Ca5b");
            const ret = await contract.hasRole(RET_ROLE, "0x713142CCd87E35683CEC7b68eF08aaE7355fABa6");
            const cust = await contract.hasRole(CUST_ROLE, "0x3769ebBC2dEDA8eD8330C7667af89313DB0162A3");

            alert(
                `Manufacturer: ${manu}\nDistributor: ${dist}\nRetailer: ${ret}\nCustomer: ${cust}`
            );
        } catch (err) {
            fail("Role check failed - " + err.message);
        }
    }

    // ── Render ───────────────────────────────────────────────
    return (
        <div style={{ padding: "24px", maxWidth: "720px", margin: "0 auto", fontFamily: "sans-serif" }}>
            <h2>Supply Chain DApp</h2>
            <h3 style={{ color: "#555", fontWeight: "normal" }}>Developed by: Umer Khalid - 22L-6546</h3>

            <section>
                <button onClick={connectWallet}>
                    {walletAddress ? "Reconnect Wallet" : "Connect Wallet"}
                </button>
                {walletAddress && (
                    <p><b>Connected:</b> {walletAddress}</p>
                )}
            </section>

            {error && <p style={{ color: "red" }}><b>Error:</b> {error}</p>}
            {success && <p style={{ color: "green" }}><b>Success:</b> {success}</p>}

            <hr />

            <section>
                <h3>Register Product</h3>
                <input
                    placeholder="Product name"
                    value={regName}
                    onChange={e => setRegName(e.target.value)}
                    style={{ display: "block", marginBottom: "8px", width: "100%" }}
                />
                <input
                    placeholder="Description"
                    value={regDesc}
                    onChange={e => setRegDesc(e.target.value)}
                    style={{ display: "block", marginBottom: "8px", width: "100%" }}
                />
                <button onClick={registerProduct}>Register Product</button>
            </section>

            <hr />

            <section>
                <h3>Product Actions</h3>
                <input
                    placeholder="Product ID"
                    value={productId}
                    onChange={e => setProductId(e.target.value)}
                    style={{ display: "block", marginBottom: "8px", width: "100%" }}
                />
                <button onClick={() => fetchProduct(productId)} style={{ marginRight: "8px" }}>
                    Get Product
                </button>
                <button onClick={loadHistory} style={{ marginRight: "8px" }}>
                    Load History
                </button>
                <button onClick={confirmDelivery}>
                    Confirm Delivery
                </button>

                <h4>Transfer Ownership</h4>
                <input
                    placeholder="New owner address (0x...)"
                    value={newOwner}
                    onChange={e => setNewOwner(e.target.value)}
                    style={{ display: "block", marginBottom: "8px", width: "100%" }}
                />
                <button onClick={transferProduct}>Transfer Product</button>
                <button onClick={checkRoles}>Check Roles</button>
            </section>

            <hr />

            {productInfo && (
                <section>
                    <h3>Product Info</h3>
                    <table style={{ borderCollapse: "collapse", width: "100%" }}>
                        <tbody>
                            {Object.entries(productInfo).map(([k, v]) => (
                                <tr key={k}>
                                    <td style={{ padding: "6px 12px 6px 0", fontWeight: "bold", textTransform: "capitalize" }}>{k}</td>
                                    <td style={{ padding: "6px", wordBreak: "break-all" }}>{v}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </section>
            )}

            <hr />

            {history.length > 0 && (
                <section>
                    <h3>Audit Trail</h3>
                    <table style={{ borderCollapse: "collapse", width: "100%", fontSize: "13px" }}>
                        <thead>
                            <tr style={{ borderBottom: "2px solid #ccc" }}>
                                <th style={{ textAlign: "left", padding: "6px" }}>#</th>
                                <th style={{ textAlign: "left", padding: "6px" }}>Owner</th>
                                <th style={{ textAlign: "left", padding: "6px" }}>Status</th>
                                <th style={{ textAlign: "left", padding: "6px" }}>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            {history.map((h, i) => (
                                <tr key={i} style={{ borderBottom: "1px solid #eee" }}>
                                    <td style={{ padding: "6px" }}>{i + 1}</td>
                                    <td style={{ padding: "6px", wordBreak: "break-all", fontSize: "11px" }}>{h.owner}</td>
                                    <td style={{ padding: "6px" }}>{h.status}</td>
                                    <td style={{ padding: "6px" }}>{h.timestamp}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </section>
            )}
        </div>
    );
}

export default App;
            