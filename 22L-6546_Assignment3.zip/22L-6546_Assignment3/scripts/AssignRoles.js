const hre = require("hardhat");

async function main() {
    const contractAddress = "0x951897b876E309F031f0DB6A7BfB4Af63544c445";

  const contract = await hre.ethers.getContractAt(
    "UmerKhalid_SupplyChain",
    contractAddress
  );

  const MANUFACTURER_ROLE = await contract.MANUFACTURER_ROLE();
  const DISTRIBUTOR_ROLE = await contract.DISTRIBUTOR_ROLE();
  const RETAILER_ROLE = await contract.RETAILER_ROLE();
  const CUSTOMER_ROLE = await contract.CUSTOMER_ROLE();

  const manufacturer = "0x93BA8Ee096C7B80F358AEAEd24a49Fc7b3B0E65E";
  const distributor = "0x59e2AeC261C8B3238a051ff9c9086C3d9079Ca5b";
  const retailer = "0x713142CCd87E35683CEC7b68eF08aaE7355fABa6";
  const customer = "0x3769ebBC2dEDA8eD8330C7667af89313DB0162A3";   
  
    const tx1 = await contract.grantRole(MANUFACTURER_ROLE, manufacturer);
    await tx1.wait();

    const tx2 = await contract.grantRole(DISTRIBUTOR_ROLE, distributor);
    await tx2.wait();

    const tx3 = await contract.grantRole(RETAILER_ROLE, retailer);
    await tx3.wait();

    const tx4 = await contract.grantRole(CUSTOMER_ROLE, customer);
    await tx4.wait();

    console.log("Roles assigned successfully");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});